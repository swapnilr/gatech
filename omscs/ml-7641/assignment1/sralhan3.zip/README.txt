All programs were run through the WEKA GUI. This is done by running  java -classpath $CLASSPATH:weka.jar:libsvm.jar weka.gui.GUIChooser. 

The algorithms chosen specifically were classifiers > trees > J48 for Decision Trees, classifiers > functions > Multilayer Perceptron for Neural Networks, classifiers > meta > AdaBoostM1 with J48 for boosting, classifiers > functions > LibSVM for SVM and classifiers > lazy > IBk for k nearest neighbors

The datasets were obtained from http://www.cs.waikato.ac.nz/ml/weka/datasets.html, and the actual source of the data is listed in the files.
