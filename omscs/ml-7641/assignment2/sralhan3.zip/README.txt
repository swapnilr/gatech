The data for the file is in modifiedLetter.data.
Compile DataSetReadingTest.java with ABAGAIL.jar and run with java DataSetReadingTest
I used ABAGAIL for my coding, and problems, and my problems are in Tests.java. It can be run with java(compiled with -jar ABAGAIL.jar), and run with java Tests.

