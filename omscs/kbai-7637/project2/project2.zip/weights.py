Weights = {'shape':50}
